package io.agileintelligence.fsbasics1backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fsbasics1BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
