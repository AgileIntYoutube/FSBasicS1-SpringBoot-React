package io.agileintelligence.fsbasics1backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fsbasics1BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Fsbasics1BackendApplication.class, args);
	}

}
